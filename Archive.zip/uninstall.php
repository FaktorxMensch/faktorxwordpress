<?php
// Prevent direct file access
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit;

// code to execute on plugin uninstallation
